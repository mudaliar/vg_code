## v0.1.0:

-Base line Version

## v0.1.1:

-Supports centos and opensuse 12.1

## v0.1.2:

-Supports fedora and install and configure specified version.

## v0.1.3:

-Can specify the user to run tomcat as and bug fix on the version specification.

## v0.1.4:

-Support for java_opts and Ubuntu

## v0.1.5:

-Support for auto_start attribute and Debian Linux

## v0.1.6:

-Bug fix: If the recipe is already installed do not download and install tomcat.

Chef::Log.fatal("

java::ibm_tar recipe is now deprecated
Using one of the documented install resources
See the documentation folder for a list of resources

")

raise 'Recipe used instead of custom resource'
